<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGST - Painel de Gestão de Salas</title>
    <link rel="stylesheet" href="./Public/CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="page-container">
        <aside class="sidebar">
            <nav class="sidebar-nav">
                <ul>
                    <li>
                        <a href="#" class="nav-item active" data-target="painel-visual">
                            <i class="fas fa-calendar-alt"></i>
                            <span>Painel Visual (Agenda)</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="nav-item" data-target="calculadora-inteligente">
                            <i class="fas fa-calculator"></i>
                            <span>Calculadora Inteligente</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="nav-item" data-target="gerenciar-instrutores">
                            <i class="fas fa-user-tie"></i>
                            <span>Gerenciar Instrutores</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="nav-item" data-target="gerenciar-cursos">
                            <i class="fas fa-book"></i>
                            <span>Gerenciar Cursos</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="nav-item" data-target="integracoes">
                            <i class="fas fa-puzzle-piece"></i>
                            <span>Integração Futuras</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
        <div class="main-content-wrapper">
            <section id="painel-visual" class="content-section active">
                <header class="page-header">
                    <h1>Painel Visual de Salas</h1>
                    <div class="header-actions">
                        <button id="gerenciar-feriados" class="secondary-btn"><i class="fas fa-calendar-times"></i> Adicionar Feriados</button>
                        <button id="add-turma-btn" class="primary-btn"><i class="fas fa-plus"></i> Agendar Turma</button>
                    </div>
                </header>
                <main class="main-content">
                    <div class="calendar-header">
                        <button id="prev-month-btn" class="nav-btn"><i class="fas fa-chevron-left"></i></button>
                        <h2 id="current-month-year"></h2>
                        <button id="next-month-btn" class="nav-btn"><i class="fas fa-chevron-right"></i></button>
                        <div class="filters">
                            <select id="turno-filter" class="filter-select">...</select>
                            <select id="tipo-sala-filter" class="filter-select">...</select>
                        </div>
                    </div>
                    <div id="calendar-grid" class="calendar-grid"></div>
                </main>
            </section>
            <section id="calculadora-inteligente" class="content-section">
                <header class="page-header">
                    <h1>Calculadora Inteligente</h1>
                </header>
                <main class="main-content">
                    <section class="calculator-grid">
                        <aside class="panel-calculator">
                            <h2>Filtros</h2>
                            <div class="filters-container">
                                <div class="filter-item">
                                <label for="filter-segmento">Segmento</label>
                                <select id="filter-segmento">
                                    <option value="">Todos</option>
                                </select>
                                </div>
                                <div class="filter-item">
                                <label for="filter-modalidade">Modalidade</label>
                                <select id="filter-modalidade">
                                    <option value="">Todos</option>
                                </select>
                                </div>
                                <div class="filter-item">
                                <label for="filter-nome-curso">Nome do Curso</label>
                                <input type="text" id="filter-nome-curso" placeholder="Pesquisar por nome...">
                                </div>
                                <div class="filter-item">
                                <label for="filter-ch-min">Carga Horária (Min)</label>
                                <input type="number" id="filter-ch-min" placeholder="Ex: 80">
                                </div>
                                <div class="filter-item">
                                <label for="filter-ch-max">Carga Horária (Max)</label>
                                <input type="number" id="filter-ch-max" placeholder="Ex: 160">
                                </div>
                                <div class="filter-item checkbox-group-container">
                                <div class="checkbox-group">
                                    <label><input type="checkbox" id="filter-tem"> TEM</label>
                                    <label><input ztype="checkbox" id="filter-bolsa"> Bolsa</label>
                                </div>
                                </div>
                            </div>
                            <div class="action-buttons">
                                <button id="apply-filters-button">Aplicar Filtros</button>
                                <button id="clear-filters-button">Limpar Filtros</button>
                            </div>
                        </aside>

                        <section class="panel-calculator">
                            <h2>Dados do Cronograma</h2>
                            <form id="course-form">
                                <div class="form-group">
                                    <label for="calculadora-curso-select">Selecione o Curso:</label>
                                    <select id="calculadora-curso-select">
                                        <option value="">Selecione um curso</option>
                                    </select>
                                </div>

                                <div id="course-details" class="hidden">
                                    <p><strong>Carga Horária:</strong> <span id="display-ch"></span></p>
                                    <p><strong>Valor:</strong> R$ <span id="display-valor"></span></p>
                                </div>
                                <div class="form-group">
                                    <label for="calculadora-data-inicio">Data de Início:</label>
                                    <input type="date" id="calculadora-data-inicio">
                                </div>
                                <div class="form-group">
                                    <label for="calculadora-turno">Turno:</label>
                                    <select id="calculadora-turno">
                                        <option value="manhã">Manhã (08h - 12h)</option>
                                        <option value="tarde">Tarde (13h - 17h)</option>
                                        <option value="noite">Noite (18h - 22h)</option>
                                        <option value="integral">Integral (08h - 17h)</option>
                                    </select>
                                </div>
                                
                                <div class="form-group">
                                    <label for="calculadora-porcentagem-remoto">Porcentagem Remota</label>
                                    <select id="calculadora-porcentagem-remoto" name="calculadora-porcentagem-remoto">
                                        <option value="0">0% (Presencial)</option>
                                        <option value="10">10%</option>
                                        <option value="20">20%</option>
                                        <option value="100">100% (Remoto)</option>
                                    </select>
                                </div>
                                <div id="remote-details-options" class="toggle-section hidden"></div>
                                <div id="remote-details-options" class="hidden">
                                    <label>Dias Remotos</label>
                                    <div class="checkbox-group" id="calculadora-dias-semana">
                                        <label><input type="checkbox" data-day="segunda" checked> Seg</label>
                                        <label><input type="checkbox" data-day="terça" checked> Ter</label>
                                        <label><input type="checkbox" data-day="quarta" checked> Qua</label>
                                        <label><input type="checkbox" data-day="quinta" checked> Qui</label>
                                        <label><input type="checkbox" data-day="sexta" checked> Sex</label>
                                    </div>
                                </div>
                                <div class="form-group hidden" id="tem-options">
                                    <div class="toggle-section">
                                        <label>Opções de TEM</label>
                                        <div id="tem-800h-options" class="hidden">
                                            <label>
                                                <input type="radio" name="tem-model" value="120h" checked> Modelo 120h (Presencial)
                                                <div class="tooltip-container">
                                                    <span class="tooltip-icon">?</span>
                                                    <span class="tooltip-text">Aulas presenciais nos 3 primeiros meses e 4 horas de estudo em casa (44h/mês)</span>
                                                </div>
                                            </label>
                                        </div>
                                        <div id="tem-1200h-options" class="hidden">
                                            <label>
                                                <input type="radio" name="tem-model" value="260h" checked> Modelo 260h (Presencial)
                                                <div class="tooltip-container">
                                                    <span class="tooltip-icon">?</span>
                                                    <span class="tooltip-text">Aulas presenciais nos 3 primeiros meses e 4 horas de estudo em casa (144h/mês)</span>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group hidden" id="aprendizagem-options">
                                    <div class="toggle-section">
                                        <label>Opções de Aprendizagem</label>
                                        <div id="aprendizagem-tradicional-options" class="hidden">
                                            <label>
                                                <input type="radio" name="aprendizagem-model" value="tradicional" checked> Modelo Tradicional
                                                <div class="tooltip-container">
                                                    <span class="tooltip-icon">?</span>
                                                    <span class="tooltip-text">4 dias em empresa e 1 dia no Senac</span>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group hidden" id="aprendizagem-options">
                                    <div class="toggle-section">
                                        <label>Opções de Aprendizagem</label>
                                        <div id="aprendizagem-tradicional-options" class="hidden">
                                            <label>
                                                <input type="radio" name="aprendizagem-model" value="tradicional" checked> Modelo Tradicional
                                                <div class="tooltip-container">
                                                    <span class="tooltip-icon">?</span>
                                                    <span class="tooltip-text">4 dias em empresa e 1 dia no Senac</span>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </section>
                    </section>
                    <div class="results-section hidden" id="results-section">
                        <h2>Cronograma Gerado</h2>
                        <div id="results-content">
                            <p>Preencha os dados e clique em Gerar Cronograma para visualizar os resultados aqui.</p>
                            <div id="metrics-panel" class="metrics-panel hidden">
                                <div class="metric-card">
                                    <span>Carga Horária Total</span>
                                    <p><span id="total-hours-value">0</span>h</p>
                                </div>
                                <div class="metric-card">
                                    <span>Duração Estimada</span>
                                    <p><span id="duration-value">0</span> dias</p>
                                </div>
                            </div>
                            
                            <div class="progress-bar-container hidden">
                                <div class="progress-bar">
                                    <div id="progress-presencial" class="progress-fill" style="width: 0%;"></div>
                                    <div id="progress-remoto" class="progress-fill" style="width: 0%;"></div>
                                    <div id="progress-empresa" class="progress-fill" style="width: 0%;"></div>
                                </div>
                            </div>
                            <div class="progress-legend hidden">
                                <div class="legend-item"><span class="legend-color" style="background-color: #4CAF50;"></span><span class="legend-text">Presencial</span></div>
                                <div class="legend-item"><span class="legend-color" style="background-color: #2196F3;"></span><span class="legend-text">Remoto</span></div>
                                <div class="legend-item"><span class="legend-color" style="background-color: #FFC107;"></span><span class="legend-text">Empresa</span></div>
                            </div>

                            <div id="calendar-visual" class="calendar-visual hidden"></div>
                            <p id="holiday-info" style="font-size: 0.9em; color: #555; margin-top: 20px;"></p>
                            <button id="export-pdf-button" class="hidden">Exportar para PDF</button>
                        </div>
                    </div>
                </main>
            </section>

            <section id="gerenciar-instrutores" class="content-section">
                <header class="page-header">
                    <h1>Gerenciar Instrutores (e Habilitações)</h1>
                    <button id="add-instrutor-btn" class="primary-btn"><i class="fas fa-user-plus"></i> Adicionar Instrutor</button>
                </header>
                <div id="instrutor-list"></div>
            </section>

            <section id="gerenciar-cursos" class="content-section">
                <header class="page-header">
                    <h1>Gerenciar Cursos</h1>
                    <button id="add-curso-btn" class="primary-btn"><i class="fas fa-plus-square"></i> Adicionar Curso</button>
                </header>
                <div id="curso-list"></div>
            </section>

            <section id="integracoes" class="content-section"></section>
        </div>
    </div>
    <div id="agendamento-modal" class="modal">
        <div class="modal-content">
            <header class="modal-header">
                <h2>Agendar Turma</h2>
                <button class="close-btn">&times;</button>
            </header>
            <form id="agendamento-form">
                <div class="form-group">
                    <label for="agendamento-curso">Curso</label>
                    <select id="agendamento-curso" required></select>
                </div>
                <div class="form-group">
                    <label for="agendamento-instrutor">Instrutor</label>
                    <select id="agendamento-instrutor" required></select>
                </div>
                <div class="form-group">
                    <label for="agendamento-codigo">Codigo da Turma</label>
                    <input id="agendamento-codigo" required></select>
                </div>
                <div class="form-group">
                    <label for="agendamento-data-inicio">Data de Início</label>
                    <input type="date" id="agendamento-data-inicio" required>
                </div>
                <div class="form-group">
                    <label for="agendamento-total-alunos">Número de Alunos</label>
                    <input type="number" id="agendamento-total-alunos" required>
                </div>
                <div class="form-group">
                    <label for="agendamento-turno">Turno</label>
                    <select id="agendamento-turno" required>
                        <option value="Manhã">Manhã</option>
                        <option value="Tarde">Tarde</option>
                        <option value="Noite">Noite</option>
                        <option value="Integral">Integral</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Dias da Semana</label>
                    <div id="agendamento-dias-semana" class="dias-semana-checkbox">
                        <input type="checkbox" id="segunda" name="diasSemana" value="1"><label for="segunda">Seg</label>
                        <input type="checkbox" id="terca" name="diasSemana" value="2"><label for="terca">Ter</label>
                        <input type="checkbox" id="quarta" name="diasSemana" value="3"><label for="quarta">Qua</label>
                        <input type="checkbox" id="quinta" name="diasSemana" value="4"><label for="quinta">Qui</label>
                        <input type="checkbox" id="sexta" name="diasSemana" value="5"><label for="sexta">Sex</label>
                    </div>
                </div>
                <div class="form-group">
                    <label for="agendamento-salas-display">Sala(s)</label>
                    <input type="text" id="agendamento-salas-display" readonly placeholder="Clique para buscar salas disponíveis">
                    <input type="hidden" id="agendamento-salas-id">
                    <button type="button" class="primary-btn" id="alocar-sala-btn">Buscar Salas Automaticamente</button>
                </div>
                <div id="salasAlocadasInfo" class="alocacao-info"></div>
                <div class="form-actions">
                    <button type="submit" class="primary-btn">Agendar</button>
                    <button type="button" id="cancelar-alocacao-btn" class="secondary-btn">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <div id="feriado-modal" class="modal">
        <div class="modal-content large">
            <header class="modal-header">
                <h2>Gerenciar Feriados e Recessos</h2>
                <button class="close-btn" data-modal="feriado-modal">&times;</button>
            </header>
            
            <div class="feriado-manager-container">
                
                <div class="feriado-form-section">
                    <h3><span id="feriado-form-title">Adicionar</span> Data Não Letiva</h3>
                    <form id="feriado-form">
                        <input type="hidden" id="feriado-id">
                        <div class="form-group">
                            <label for="feriado-data">Data</label>
                            <input type="date" id="feriado-data" required>
                        </div>
                        <div class="form-group">
                            <label for="feriado-descricao">Descrição (Ex: Carnaval)</label>
                            <input type="text" id="feriado-descricao" required>
                        </div>
                        <div class="form-group">
                            <label for="feriado-tipo">Tipo</label>
                            <select id="feriado-tipo" required>
                                <option value="" disabled selected>Selecione o Tipo</option>
                                <option value="Feriado">Feriado</option>
                                <option value="Recesso">Recesso</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="primary-btn" id="feriado-form-submit-btn">Salvar</button>
                            <button type="button" class="secondary-btn" id="feriado-form-cancel-btn">Cancelar/Limpar</button>
                        </div>
                    </form>
                </div>

                <div class="feriado-list-section">
                    <h3>Datas Não Letivas Cadastradas</h3>
                    <div id="feriado-list-view" class="list-view-simple">
                        <p class="loading-message">Carregando feriados...</p>
                        </div>
                </div>

            </div>
        </div>
    </div>

    <div id="detalhes-modal" class="modal">
        <div class="modal-content">
            <header class="modal-header">
                <h2 id="detalhes-titulo">Detalhes da Turma</h2>
                <button class="close-btn">&times;</button>
            </header>
            <form id="detalhes-form" class="form-detalhes">
                <p><strong>Curso:</strong> <span id="detalhes-curso"></span></p>
                <p><strong>Sala:</strong> <span id="detalhes-sala"></span></p>
                <p><strong>Datas:</strong> <span id="detalhes-datas"></span></p>
                <p><strong>Turno:</strong> <span id="detalhes-turno"></span></p>
                <p><strong>Alunos:</strong> <span id="detalhes-alunos"></span></p>
                <p><strong>Instrutor:</strong> <span id="detalhes-instrutor"></span></p>
                <p><strong>Status:</strong> <span id="detalhes-status"></span></p>
                <input type="hidden" id="detalhes-turma">
                <div class="form-group">
                    <label for="detalhes-status-select">Alterar Status</label>
                    <select id="detalhes-status-select">
                        <option value="Planejada">Planejada</option>
                        <option value="Confirmada">Confirmada</option>
                        <option value="Em Andamento">Em Andamento</option>
                        <option value="Concluída">Concluída</option>
                        <option value="Cancelada">Cancelada</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="detalhes-instrutor">Atribuir Instrutor</label>
                    <select id="detalhes-instrutor"></select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="primary-btn" id="">Salvar Alterações</button>
                    <button type="button" class="danger-btn" id="cancelar-turma-btn">Cancelar Turma</button>
                </div>
            </form>
        </div>
    </div>

    <div id="alocacao-modal" class="modal">
        <div class="modal-content">
            <header class="modal-header">
                <h2 id="alocacao-modal-title">Sugestão de Alocação Automática</h2>
                <button class="close-btn">&times;</button>
            </header>
            <div id="alocacao-confirmacao-conteudo">
                <p><strong>Curso:</strong> <span id="alocacao-curso-nome"></span></p>
                <p><strong>Data de Início:</strong> <span id="alocacao-data-inicio" data-value=""></span></p>
                <p><strong>Data de Término (Estimada):</strong> <span id="alocacao-data-termino"></span></p>
                <p><strong>Salas Sugeridas:</strong> <span id="alocacao-salas-sugeridas"></span></p>
                <input type="hidden" id="alocacao-curso-id">
                <input type="hidden" id="alocacao-total-alunos">
                <input type="hidden" id="alocacao-turno">
                <input type="hidden" id="alocacao-salas-id">
                <input type="hidden" id="alocacao-dias-semana">
                <input type="hidden" id="alocacao-instrutor-id"> 
            </div>
            <div class="form-actions">
                <button class="primary-btn" id="confirmar-alocacao-btn">Confirmar Agendamento</button>
                <button class="secondary-btn" id="cancelar-alocacao-btn">Cancelar</button>
            </div>
        </div>
    </div>
    
    <div id="instrutor-modal" class="modal">
        <div class="modal-content">
            <header class="modal-header">
                <h2 id="instrutor-modal-title">Adicionar Instrutor</h2>
                <button class="close-btn">&times;</button>
            </header>
            <form id="instrutor-form">
                <input type="hidden" id="instrutor-id">
                <div class="form-group">
                    <label for="instrutor-nome">Nome do Instrutor</label>
                    <input type="text" id="instrutor-nome" required>
                </div>
                <div class="form-actions">
                    <button type="submit" class="primary-btn">Salvar</button>
                    <button type="button" class="secondary-btn">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <div id="curso-modal" class="modal">
        <div class="modal-content">
            <header class="modal-header">
                <h2 id="curso-modal-title">Adicionar Curso</h2>
                <button class="close-btn">&times;</button>
            </header>
            <form id="curso-form">
                <input type="hidden" id="curso-id">
                <div class="form-group">
                    <label for="curso-nome">Nome do Curso</label>
                    <input type="text" id="curso-nome" required>
                </div>
                <div class="form-group">
                    <label for="curso-carga-horaria">Carga Horária</label>
                    <input type="number" id="curso-carga-horaria" required>
                </div>
                <div class="form-group">
                    <label for="curso-tipo-sala">Tipo de Sala</label>
                    <select id="curso-tipo-sala" required></select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="primary-btn">Salvar</button>
                    <button type="button" class="secondary-btn">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
    <script src="./Public/JS/api.js"></script>
    <script src="./Public/JS/utils.js"></script>
    <script src="./Public/JS/modals.js"></script>
    <script src="./Public/JS/agendar_turma.js"></script>
    <script src="./Public/JS/alocacao_automatica.js"></script>
    <script src="./Public/JS/gerenciar_feriados.js"></script>
    <script src="./Public/JS/gerenciar_instrutores.js"></script>
    <script src="./Public/JS/gerenciar_cursos.js"></script>
    <script src="./Public/JS/calculadora.js"></script>
    <script src="./Public/JS/painel.js"></script>
    <script src="./Public/JS/detalhe_turma.js"></script>
    <script src="./Public/JS/script.js"></script>
</body>
</html>