<?php
require_once 'Database.php';

class CursoModel {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function getAllCursos() {
        $sql = "SELECT c.*, ts.nome_tipo 
                FROM cursos c
                LEFT JOIN tipos_sala ts ON c.idTipo_sala = ts.idTipo_sala
                ORDER BY c.nome_curso";
        return $this->db->fetchAll($sql);
    }
    
    public function getSegmentos() {
        $sql = "SELECT DISTINCT segmento FROM cursos ORDER BY segmento";
        $results = $this->db->fetchAll($sql);
        return array_column($results, 'segmento');
    }
}